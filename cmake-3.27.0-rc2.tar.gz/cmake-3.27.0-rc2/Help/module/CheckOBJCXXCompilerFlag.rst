.. cmake-module:: ../../Modules/CheckOBJCXXCompilerFlag.cmake
